import { useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';
import * as THREE from 'three';

const MIN_MARKER_SEPARATION = THREE.MathUtils.degToRad(4.8);
const FALLBACK_MARKER_IMAGES = [
  'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
];
const MARKER_POSITION_CANDIDATES = [];

for (let latitude = -84; latitude <= 84; latitude += 4) {
  for (let longitude = -180; longitude < 180; longitude += 4) {
    const lat = THREE.MathUtils.degToRad(latitude);
    const lon = THREE.MathUtils.degToRad(longitude);
    MARKER_POSITION_CANDIDATES.push(new THREE.Vector3(
      Math.cos(lat) * Math.cos(lon),
      Math.sin(lat),
      -Math.cos(lat) * Math.sin(lon)
    ));
  }
}

function getSpacedMarkerNormals(markers) {
  const placedNormals = [];
  const minDotProduct = Math.cos(MIN_MARKER_SEPARATION);

  markers.forEach(({ latitude, longitude }) => {
    const lat = THREE.MathUtils.degToRad(latitude);
    const lon = THREE.MathUtils.degToRad(longitude);
    const preferredNormal = new THREE.Vector3(
      Math.cos(lat) * Math.cos(lon),
      Math.sin(lat),
      -Math.cos(lat) * Math.sin(lon)
    );
    const overlaps = (normal) => placedNormals.some((placed) => normal.dot(placed) > minDotProduct);

    if (!overlaps(preferredNormal)) {
      placedNormals.push(preferredNormal);
      return;
    }

    let bestNormal = null;
    let bestAlignment = -Infinity;
    MARKER_POSITION_CANDIDATES.forEach((candidate) => {
      const alignment = candidate.dot(preferredNormal);
      if (alignment > bestAlignment && !overlaps(candidate)) {
        bestNormal = candidate;
        bestAlignment = alignment;
      }
    });

    if (!bestNormal) {
      throw new Error('Unable to place a globe image marker without overlap.');
    }
    placedNormals.push(bestNormal.clone());
  });

  return placedNormals;
}


export default function RotatingGlobe({ size = 380, isRotating = true }) {
  const mountRef = useRef(null);
  const frameIdRef = useRef(null);
  const [selectedProfile, setSelectedProfile] = useState(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = size;
    const height = size;

    // 1. Scene & Camera Setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = 2.8;

    // 2. WebGL Renderer with Alpha transparency
    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance'
      });
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      container.appendChild(renderer.domElement);
    } catch (e) {
      console.warn('WebGL init failed, using fallback', e);
      return;
    }

    // 3. Earth surface and city-light maps
    const textureLoader = new THREE.TextureLoader();
    const earthTexture = textureLoader.load(
      `${import.meta.env.BASE_URL}assets/earth-atmos-2048.jpg`,
      undefined,
      undefined,
      (error) => console.error('Failed to load the Earth surface map.', error)
    );
    earthTexture.colorSpace = THREE.SRGBColorSpace;

    const nightLightsTexture = textureLoader.load(
      `${import.meta.env.BASE_URL}assets/earth-night-lights-2048.png`,
      undefined,
      undefined,
      (error) => console.error('Failed to load the Earth night-lights map.', error)
    );
    nightLightsTexture.colorSpace = THREE.SRGBColorSpace;

    // 4. Globe Sphere & Material
    const earthGroup = new THREE.Group();
    scene.add(earthGroup);

    const globeGeometry = new THREE.SphereGeometry(1, 64, 64);

    const globeMaterial = new THREE.MeshPhongMaterial({
      map: earthTexture,
      bumpMap: earthTexture,
      bumpScale: 0.018,
      shininess: 25,
      specular: new THREE.Color(0x4A6B8A)
    });

    const globeMesh = new THREE.Mesh(globeGeometry, globeMaterial);
    earthGroup.add(globeMesh);

    const markerGeometry = new THREE.CircleGeometry(0.042, 48);
    const borderGeometry = new THREE.RingGeometry(0.040, 0.044, 48);
    const borderMaterial = new THREE.MeshBasicMaterial({
      color: 0xF59E0B,
      side: THREE.DoubleSide
    });
    const markerMaterials = [];
    const markerMeshes = [];
    let isDisposed = false;
    const imageMarkers = [
      // India & South Asia (Evenly distributed directly across the Indian Map)
      { name: 'Priyanka Chopra Jonas — Mumbai, Maharashtra', image: 'https://images.unsplash.com/photo-1541647376583-8934aaf3448a?auto=format&fit=crop&w=300&q=80', latitude: 18.9220, longitude: 72.8347 },
      { name: 'Allu Arjun — Hyderabad, Telangana', image: 'https://images.unsplash.com/photo-1542206395-9feb3edaa68d?auto=format&fit=crop&w=300&q=80', latitude: 17.8200, longitude: 78.4200 },
      { name: 'Rajinikanth — Chennai, Tamil Nadu', image: 'https://images.unsplash.com/photo-1507081323647-4d250478b919?auto=format&fit=crop&w=300&q=80', latitude: 12.8500, longitude: 80.2500 },
      { name: 'Sabu Cyril — New Delhi NCR', image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=300&q=80', latitude: 28.6139, longitude: 77.2090 },
      { name: 'Sunitha — Kolkata, West Bengal', image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=300&q=80', latitude: 22.5726, longitude: 88.3639 },
      { name: 'Nani — Lucknow / Varanasi, Uttar Pradesh', image: 'https://images.unsplash.com/photo-1521119989659-a83eee488004?auto=format&fit=crop&w=300&q=80', latitude: 26.8500, longitude: 82.5000 },
      { name: 'Film professional — Srinagar, Kashmir', image: 'https://images.unsplash.com/photo-1509783236416-c9ad59bae472?auto=format&fit=crop&w=300&q=80', latitude: 34.2000, longitude: 74.8000 },
      { name: 'Film professional — Kutch / Ahmedabad, Gujarat', image: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=300&q=80', latitude: 23.5000, longitude: 69.8000 },
      { name: 'Film professional — Guwahati, Assam', image: 'https://images.unsplash.com/photo-1573496799652-408c2ac9fe98?auto=format&fit=crop&w=300&q=80', latitude: 26.5000, longitude: 92.5000 },
      { name: 'Film professional — Kochi / Trivandrum, Kerala', image: 'https://images.unsplash.com/photo-1543610892-0b1f7e6d8ac1?auto=format&fit=crop&w=300&q=80', latitude: 9.5000, longitude: 76.3000 },
      { name: 'S. P. Balasubrahmanyam — Sri Lanka', image: 'https://images.unsplash.com/photo-1563237023-b1e970526dcb?auto=format&fit=crop&w=300&q=80', latitude: 5.9500, longitude: 80.5000 },,
      // North America
      { name: 'Tom Cruise', image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80', latitude: 34.0522, longitude: -118.2437 },
      { name: 'Leonardo DiCaprio', image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80', latitude: 40.7128, longitude: -74.006 },
      { name: 'K. K. Senthil Kumar', image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80', latitude: 49.2827, longitude: -123.1207 },
      { name: 'Jandhyala', image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80', latitude: 41.8781, longitude: -87.6298 },
      { name: 'Resul Pookutty', image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80', latitude: 25.7617, longitude: -80.1918 },
      { name: 'Nagarjuna Akkineni', image: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=300&q=80', latitude: 21.3069, longitude: -157.8583 },
      { name: 'Mahesh Babu', image: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80', latitude: 37.3382, longitude: -121.8863 },
      { name: 'Film professional — Mexico City, Mexico', image: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80', latitude: 19.4326, longitude: -99.1332 },
      { name: 'Film professional — Toronto, Canada', image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80', latitude: 53.5461, longitude: -113.4938 },

      // South America
      { name: 'Suresh Babu', image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=300&q=80', latitude: 4.7110, longitude: -74.0721 },
      { name: 'Film professional — São Paulo, Brazil', image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80', latitude: -23.5505, longitude: -46.6333 },
      { name: 'Film professional — Buenos Aires, Argentina', image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=300&q=80', latitude: -34.6037, longitude: -58.3816 },
      { name: 'Film professional — Santiago, Chile', image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80', latitude: -33.4489, longitude: -70.6693 },
      { name: 'Film professional — Recife, Brazil', image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80', latitude: -8.0476, longitude: -34.8770 },

      // Europe
      { name: 'Idris Elba', image: 'https://images.unsplash.com/photo-1522529599102-193c0d76b5b6?auto=format&fit=crop&w=300&q=80', latitude: 51.5074, longitude: -0.1278 },
      { name: 'Penelope Cruz', image: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&w=300&q=80', latitude: 40.4168, longitude: -3.7038 },
      { name: 'Karan Johar', image: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?auto=format&fit=crop&w=300&q=80', latitude: 41.9028, longitude: 12.4964 },
      { name: 'Neeta Lulla', image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80', latitude: 59.3293, longitude: 18.0686 },
      { name: 'B. Lenin', image: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=300&q=80', latitude: 48.2082, longitude: 16.3738 },
      { name: 'P. C. Sreeram', image: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=300&q=80', latitude: 64.1466, longitude: -21.9426 },
      { name: 'Anirudh Ravichander', image: 'https://images.unsplash.com/photo-1528892952291-009c663ce843?auto=format&fit=crop&w=300&q=80', latitude: 53.4808, longitude: -2.2426 },

      // Eurasia & Russia
      { name: 'Film professional — Moscow, Russia', image: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?auto=format&fit=crop&w=300&q=80', latitude: 55.7558, longitude: 37.6173 },
      { name: 'Vijayendra Prasad', image: 'https://images.unsplash.com/photo-1530268729831-4b0b9e170218?auto=format&fit=crop&w=300&q=80', latitude: 55.0084, longitude: 82.9357 },
      { name: 'Film professional — Vladivostok, Russia', image: 'https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?auto=format&fit=crop&w=300&q=80', latitude: 62.0355, longitude: 129.6755 },

      // Africa & Middle East
      { name: 'Farah Khan', image: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?auto=format&fit=crop&w=300&q=80', latitude: 30.0444, longitude: 31.2357 },
      { name: 'Dil Raju', image: 'https://images.unsplash.com/photo-1564564321837-a57b7070ac4f?auto=format&fit=crop&w=300&q=80', latitude: 25.2048, longitude: 55.2708 },
      { name: 'A. R. Rahman', image: 'https://images.unsplash.com/photo-1507591064344-4c6ce005b128?auto=format&fit=crop&w=300&q=80', latitude: 24.4539, longitude: 54.3773 },
      { name: 'Thota Tharani', image: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80', latitude: 41.0082, longitude: 28.9784 },
      { name: 'Aamir Khan', image: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?auto=format&fit=crop&w=300&q=80', latitude: 41.2995, longitude: 69.2401 },
      { name: 'Film professional — Lagos, Nigeria', image: 'https://images.unsplash.com/photo-1531384441138-2736e62e0919?auto=format&fit=crop&w=300&q=80', latitude: 6.5244, longitude: 3.3792 },
      { name: 'Film professional — Cape Town, South Africa', image: 'https://images.unsplash.com/photo-1517462964-21fdcec3f25b?auto=format&fit=crop&w=300&q=80', latitude: -33.9249, longitude: 18.4241 },
      { name: 'Film professional — Nairobi, Kenya', image: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80', latitude: -1.2921, longitude: 36.8219 },
      { name: 'Film professional — Dakar, Senegal', image: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&w=300&q=80', latitude: 14.7167, longitude: -17.4677 },
      { name: 'Khesari Lal Yadav', image: 'https://images.unsplash.com/photo-1519058082700-08a0b56da9b4?auto=format&fit=crop&w=300&q=80', latitude: -18.8792, longitude: 47.5079 },
      { name: 'Vijay Sethupathi', image: 'https://images.unsplash.com/photo-1552058544-f2b08422138a?auto=format&fit=crop&w=300&q=80', latitude: -20.1609, longitude: 57.5012 },


      // East & Southeast Asia
      { name: 'Jackie Chan', image: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&w=300&q=80', latitude: 22.3193, longitude: 114.1694 },
      { name: 'Gong Li', image: 'https://images.unsplash.com/photo-1548142813-c348350df52b?auto=format&fit=crop&w=300&q=80', latitude: 39.9042, longitude: 116.4074 },
      { name: 'Tony Leung Chiu-wai', image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80', latitude: 13.7563, longitude: 100.5018 },
      { name: 'Michelle Yeoh', image: 'https://images.unsplash.com/photo-1520813792240-56fc4a3765a7?auto=format&fit=crop&w=300&q=80', latitude: 1.3521, longitude: 103.8198 },
      { name: 'Shankar', image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=300&q=80', latitude: 3.1390, longitude: 101.6869 },
      { name: 'Bong Joon-ho', image: 'https://images.unsplash.com/photo-1523450001312-faa4e2e37f0f?auto=format&fit=crop&w=300&q=80', latitude: 35.6762, longitude: 139.6503 },
      { name: 'Samantha Ruth Prabhu', image: 'https://images.unsplash.com/photo-1524250502761-1ac6f2e30d43?auto=format&fit=crop&w=300&q=80', latitude: -6.2088, longitude: 106.8456 },
      { name: 'Film professional — Manila, Philippines', image: 'https://images.unsplash.com/photo-1525134479668-1bee5c7c6845?auto=format&fit=crop&w=300&q=80', latitude: 14.5995, longitude: 120.9842 },

      // Oceania / Australia / Pacific
      { name: 'SS Rajamouli', image: 'https://images.unsplash.com/photo-1526080652727-5b77f74eacd2?auto=format&fit=crop&w=300&q=80', latitude: -33.8688, longitude: 151.2093 },
      { name: 'Trivikram Srinivas', image: 'https://images.unsplash.com/photo-1526510747491-58f928ec870f?auto=format&fit=crop&w=300&q=80', latitude: -31.9505, longitude: 115.8605 },
      { name: 'Devi Sri Prasad', image: 'https://images.unsplash.com/photo-1527203561188-dae1bc1a417f?auto=format&fit=crop&w=300&q=80', latitude: -36.8485, longitude: 174.7633 },
      { name: 'Film professional — Darwin, Australia', image: 'https://images.unsplash.com/photo-1528763380143-65b3ac89a3ff?auto=format&fit=crop&w=300&q=80', latitude: -12.4634, longitude: 130.8456 }
    ];
    const markerNormals = getSpacedMarkerNormals(imageMarkers);

    imageMarkers.forEach(({ name, image }, index) => {
      let markerMaterial;
      const markerTexture = textureLoader.load(
        image,
        undefined,
        undefined,
        (error) => {
          console.error(`Failed to load globe marker for ${name}: ${image}`, error);
          if (isDisposed) return;

          const fallbackImage = FALLBACK_MARKER_IMAGES[index % FALLBACK_MARKER_IMAGES.length];
          textureLoader.load(
            fallbackImage,
            (fallbackTexture) => {
              fallbackTexture.colorSpace = THREE.SRGBColorSpace;
              if (isDisposed) {
                fallbackTexture.dispose();
                return;
              }
              markerMaterial.map?.dispose();
              markerMaterial.map = fallbackTexture;
              markerMaterial.needsUpdate = true;
            },
            undefined,
            (fallbackError) => console.error(`Failed to load fallback globe marker for ${name}: ${fallbackImage}`, fallbackError)
          );
        }
      );
      markerTexture.colorSpace = THREE.SRGBColorSpace;

      markerMaterial = new THREE.MeshBasicMaterial({
        map: markerTexture,
        side: THREE.DoubleSide,
        toneMapped: false
      });
      markerMaterials.push(markerMaterial);

      const markerGroup = new THREE.Group();

      const marker = new THREE.Mesh(markerGeometry, markerMaterial);
      const location = name.split(' — ').slice(1).join(' — ');
      marker.userData.profile = {
        name,
        image,
        location: location || 'Cinema professional'
      };
      markerMeshes.push(marker);
      markerGroup.add(marker);

      const border = new THREE.Mesh(borderGeometry, borderMaterial);
      border.position.z = 0.0008;
      markerGroup.add(border);

      const normal = markerNormals[index];
      const markerPosition = normal.clone().multiplyScalar(1.020);
      const markerScale = 1.0;

      markerGroup.scale.setScalar(markerScale);
      markerGroup.position.copy(markerPosition);
      markerGroup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
      markerGroup.renderOrder = 3;
      earthGroup.add(markerGroup);
    });

    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    const handleMarkerClick = (event) => {
      const bounds = renderer.domElement.getBoundingClientRect();
      pointer.x = ((event.clientX - bounds.left) / bounds.width) * 2 - 1;
      pointer.y = -((event.clientY - bounds.top) / bounds.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);

      const markerHit = raycaster.intersectObjects(markerMeshes, false)[0];
      const globeHit = raycaster.intersectObject(globeMesh, false)[0];
      if (markerHit && (!globeHit || markerHit.distance < globeHit.distance)) {
        setSelectedProfile(markerHit.object.userData.profile);
      } else {
        setSelectedProfile(null);
      }
    };
    renderer.domElement.addEventListener('click', handleMarkerClick);
    renderer.domElement.style.pointerEvents = 'auto';

    const nightLightsMaterial = new THREE.ShaderMaterial({
      uniforms: {
        uNightLights: { value: nightLightsTexture },
        uSunDirection: { value: new THREE.Vector3(5, 3, 5).normalize() }
      },
      vertexShader: `
        varying vec2 vUv;
        varying vec3 vWorldNormal;
        void main() {
          vUv = uv;
          vWorldNormal = normalize(mat3(modelMatrix) * normal);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform sampler2D uNightLights;
        uniform vec3 uSunDirection;
        varying vec2 vUv;
        varying vec3 vWorldNormal;
        void main() {
          vec3 lights = texture2D(uNightLights, vUv).rgb;
          float brightness = dot(lights, vec3(0.299, 0.587, 0.114));
          float cityLights = smoothstep(0.16, 0.55, brightness);
          float nightSide = 1.0 - smoothstep(-0.15, 0.12, dot(normalize(vWorldNormal), uSunDirection));
          float glow = cityLights * nightSide;
          gl_FragColor = vec4(vec3(1.0, 0.62, 0.24) * brightness * 2.0, glow);
        }
      `,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      transparent: true
    });
    const nightLightsMesh = new THREE.Mesh(
      new THREE.SphereGeometry(1.003, 64, 64),
      nightLightsMaterial
    );
    earthGroup.add(nightLightsMesh);

    // 5. Atmospheric Outer Glow Shell (Luminous Blue & Warm Golden cinematic rim)
    const atmosphereGeometry = new THREE.SphereGeometry(1.045, 64, 64);
    const atmosphereMaterial = new THREE.ShaderMaterial({
      vertexShader: `
        varying vec3 vNormal;
        void main() {
          vNormal = normalize(normalMatrix * normal);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vNormal;
        void main() {
          float rim = pow(0.72 - dot(vNormal, vec3(0.0, 0.0, 1.0)), 2.0);
          vec3 blueGlow = vec3(0.14, 0.65, 1.0) * 1.8;
          vec3 warmRim = vec3(0.96, 0.62, 0.12) * 0.8;
          vec3 finalColor = mix(blueGlow, warmRim, clamp(vNormal.x * 0.5 + 0.5, 0.0, 1.0));
          gl_FragColor = vec4(finalColor, 1.0) * rim * 2.0;
        }
      `,
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      transparent: true
    });

    const atmosphereMesh = new THREE.Mesh(atmosphereGeometry, atmosphereMaterial);
    earthGroup.add(atmosphereMesh);

    // 6. Natural Sunlight, Golden Rim, Front Fill & Ambient Lighting
    const ambientLight = new THREE.AmbientLight(0x384B68, 1.4);
    scene.add(ambientLight);

    // Key Sunlight (Bright warm sunlight)
    const sunLight = new THREE.DirectionalLight(0xFFFBEB, 3.2);
    sunLight.position.set(5, 3.5, 4.5);
    scene.add(sunLight);

    // Front Camera Fill Light (Brings out vivid continent colors & portraits)
    const frontFillLight = new THREE.DirectionalLight(0xE0F2FE, 1.2);
    frontFillLight.position.set(0, 1.5, 5);
    scene.add(frontFillLight);

    // Golden Cinema Accent Light (Highlights edges and cinema talents)
    const goldenAccentLight = new THREE.DirectionalLight(0xF59E0B, 1.5);
    goldenAccentLight.position.set(-3.5, 2.5, 2);
    scene.add(goldenAccentLight);

    // Deep Cosmic Blue Rim Light (Backlighting)
    const blueBackLight = new THREE.DirectionalLight(0x0EA5E9, 1.4);
    blueBackLight.position.set(-5, -2.5, -4);
    scene.add(blueBackLight);

    // 7. Golden Cinematic Particle Nebula Dust around the Globe
    const particleCount = 180;
    const particleGeometry = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      const radius = 1.35 + Math.random() * 0.9;
      const theta = Math.random() * Math.PI * 2;
      const phi = (Math.random() - 0.5) * Math.PI * 0.8;
      particlePositions[i] = radius * Math.cos(phi) * Math.sin(theta);
      particlePositions[i + 1] = radius * Math.sin(phi);
      particlePositions[i + 2] = radius * Math.cos(phi) * Math.cos(theta);
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMaterial = new THREE.PointsMaterial({
      color: 0xF59E0B,
      size: 0.022,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending
    });

    const particles = new THREE.Points(particleGeometry, particleMaterial);
    earthGroup.add(particles);

    // Initial slight axial tilt (Earth's 23.5 degrees) and face India toward user on first load
    earthGroup.rotation.x = 0.22;
    earthGroup.rotation.y = 3.32; // ~190 degrees, lands directly facing India
    earthGroup.rotation.z = -0.15;

    // 8. 60 FPS Render Loop
    const animate = () => {
      frameIdRef.current = requestAnimationFrame(animate);

      // Continuous rotation around Y axis
      if (isRotating && earthGroup) {
        earthGroup.rotation.y += 0.0075;
      }

      particles.rotation.y += 0.001;
      renderer.render(scene, camera);
    };

    animate();

    // 9. Cleanup on unmount
    return () => {
      isDisposed = true;
      renderer.domElement.removeEventListener('click', handleMarkerClick);
      if (frameIdRef.current) cancelAnimationFrame(frameIdRef.current);
      if (renderer) {
        renderer.dispose();
        if (renderer.domElement && container.contains(renderer.domElement)) {
          container.removeChild(renderer.domElement);
        }
      }
      globeGeometry.dispose();
      globeMaterial.dispose();
      nightLightsMesh.geometry.dispose();
      nightLightsMaterial.dispose();
      markerGeometry.dispose();
      borderGeometry.dispose();
      borderMaterial.dispose();
      markerMaterials.forEach((material) => {
        material.map?.dispose();
        material.dispose();
      });
      atmosphereGeometry.dispose();
      atmosphereMaterial.dispose();
      earthTexture.dispose();
      nightLightsTexture.dispose();
      particleGeometry.dispose();
      particleMaterial.dispose();
    };
  }, [size, isRotating]);

  return (
    <div className="globe-interaction-shell" style={{ width: `${size}px`, height: `${size}px` }}>
      <div
        ref={mountRef}
        className="rotating-globe-mount"
        style={{
          width: `${size}px`,
          height: `${size}px`,
          position: 'relative',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          filter: 'drop-shadow(0 0 45px rgba(14, 165, 233, 0.35))'
        }}
        aria-label="3D Rotating Earth Globe"
        role="img"
      />
      {selectedProfile && (
        <div className="globe-profile-card" role="dialog" aria-label={`${selectedProfile.name} profile`}>
          <button
            type="button"
            className="globe-profile-close"
            onClick={() => setSelectedProfile(null)}
            aria-label="Close profile card"
          >
            <X size={16} />
          </button>
          <img
            className="globe-profile-image"
            src={selectedProfile.image}
            alt={selectedProfile.name}
            onError={(event) => {
              event.currentTarget.onerror = null;
              event.currentTarget.src = FALLBACK_MARKER_IMAGES[0];
            }}
          />
          <div className="globe-profile-label">Cinema talent</div>
          <h3>{selectedProfile.name}</h3>
          <p>{selectedProfile.location}</p>
        </div>
      )}
    </div>
  );
}
